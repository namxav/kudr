import React from 'react'
import './admin.css'

const admin = () => {
  return (
    <div></div>
  )
}

export default admin