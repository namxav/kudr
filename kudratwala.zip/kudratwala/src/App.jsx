import { useState } from 'react';
import reactLogo from './assets/react.svg';
import viteLogo from '/vite.svg';
import './App.css';
import Admin from './component/admin/admin'
import Login from './component/login/login'
import RegistrationPage from './component/registration/registration';

function App() {
  const [count, setCount] = useState(false);

  function change() {
    return setCount(!count);
  }

  return (
    <>
    <Admin/>
    <Login/> 
    <RegistrationPage/>

    </>
  );
}

export default App;
